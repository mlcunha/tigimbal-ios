function Controller() {
    function init() {
        tigimbal.init({
            setAppId: "c127eb2eb823729a8899d5d212186695cea1811324d5d26dd079dc693b90889a",
            appSecret: "488927e4e34ff34332126d4c9ee6fc8a56c64f3f5f5aca85ceb2e60d693f22c0",
            callbackUrl: "tigimbal://authcode"
        });
        $.startSession.enabled = true;
        $.startService.enabled = true;
    }
    function startStopService() {
        if ($.startService.on) {
            $.startService.on = false;
            $.startService.title = "Start Service";
            tigimbal.stopService();
        } else {
            $.startService.on = true;
            $.startService.title = "Stop Service";
            tigimbal.startService();
        }
    }
    function startStopSession() {
        if ($.startSession.on) {
            $.startSession.on = false;
            $.startSession.title = "Start Session";
            tigimbal.stopServiceAndDeauthorize();
        } else {
            $.startSession.on = true;
            $.startSession.title = "Stop Session";
            tigimbal.startServiceAndAuthorize();
        }
    }
    function deleteVisitsAndSightings() {
        tigimbal.deleteVisitsAndSightings();
    }
    function setFileLogging(e) {
        console.log(e.value);
        1 == e.value ? tigimbal.enableFileLogging() : tigimbal.disableFileLogging();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.index = Ti.UI.createWindow({
        backgroundColor: "white",
        layout: "vertical",
        id: "index"
    });
    $.__views.index && $.addTopLevelView($.__views.index);
    $.__views.title = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        top: 20,
        text: "tiGimbal",
        id: "title"
    });
    $.__views.index.add($.__views.title);
    $.__views.__alloyId0 = Ti.UI.createView({
        borderWidth: 1,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId0"
    });
    $.__views.index.add($.__views.__alloyId0);
    $.__views.init = Ti.UI.createButton({
        id: "init",
        title: "Gimbal Init"
    });
    $.__views.__alloyId0.add($.__views.init);
    init ? $.__views.init.addEventListener("click", init) : __defers["$.__views.init!click!init"] = true;
    $.__views.startService = Ti.UI.createButton({
        left: 20,
        id: "startService",
        on: "false",
        title: "Start Service"
    });
    $.__views.__alloyId0.add($.__views.startService);
    startStopService ? $.__views.startService.addEventListener("click", startStopService) : __defers["$.__views.startService!click!startStopService"] = true;
    $.__views.startSession = Ti.UI.createButton({
        right: 20,
        id: "startSession",
        on: "false",
        title: "Start Session"
    });
    $.__views.__alloyId0.add($.__views.startSession);
    startStopSession ? $.__views.startSession.addEventListener("click", startStopSession) : __defers["$.__views.startSession!click!startStopSession"] = true;
    $.__views.__alloyId1 = Ti.UI.createView({
        borderWidth: 1,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId1"
    });
    $.__views.index.add($.__views.__alloyId1);
    $.__views.fileLoggingLabel = Ti.UI.createLabel({
        left: 20,
        text: "File Logging",
        id: "fileLoggingLabel"
    });
    $.__views.__alloyId1.add($.__views.fileLoggingLabel);
    $.__views.fileLogging = Ti.UI.createSwitch({
        right: 20,
        value: false,
        id: "fileLogging"
    });
    $.__views.__alloyId1.add($.__views.fileLogging);
    setFileLogging ? $.__views.fileLogging.addEventListener("change", setFileLogging) : __defers["$.__views.fileLogging!change!setFileLogging"] = true;
    $.__views.__alloyId2 = Ti.UI.createView({
        borderWidth: 1,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId2"
    });
    $.__views.index.add($.__views.__alloyId2);
    $.__views.deleteUserData = Ti.UI.createButton({
        id: "deleteUserData",
        title: "Delete User Data"
    });
    $.__views.__alloyId2.add($.__views.deleteUserData);
    deleteVisitsAndSightings ? $.__views.deleteUserData.addEventListener("click", deleteVisitsAndSightings) : __defers["$.__views.deleteUserData!click!deleteVisitsAndSightings"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    var tigimbal = require("com.stephenfeather.tigimbal");
    Ti.API.info("module is => " + tigimbal.moduleId);
    $.index.addEventListener("open", function() {
        console.log(Ti.App.getArguments());
        Ti.App.getArguments().url && tigimbal.handleOpenURL(Ti.App.getArguments().url);
        Ti.App.addEventListener("resume", function() {
            console.log(Ti.App.getArguments());
            Ti.App.getArguments().url && tigimbal.handleOpenURL(Ti.App.getArguments().url);
        });
    });
    $.startSession.enabled = false;
    $.startService.enabled = false;
    $.startService.on = false;
    $.startSession.on = false;
    $.index.open();
    __defers["$.__views.init!click!init"] && $.__views.init.addEventListener("click", init);
    __defers["$.__views.startService!click!startStopService"] && $.__views.startService.addEventListener("click", startStopService);
    __defers["$.__views.startSession!click!startStopSession"] && $.__views.startSession.addEventListener("click", startStopSession);
    __defers["$.__views.fileLogging!change!setFileLogging"] && $.__views.fileLogging.addEventListener("change", setFileLogging);
    __defers["$.__views.deleteUserData!click!deleteVisitsAndSightings"] && $.__views.deleteUserData.addEventListener("click", deleteVisitsAndSightings);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;