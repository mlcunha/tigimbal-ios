// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});
var label = Ti.UI.createLabel();
win.add(label);
win.open();

// TODO: write your module tests here
var tigimbal = require('com.stephenfeather.tigimbal');
Ti.API.info("module is => " + tigimbal);

tigimbal.init({setAppId: 'c127eb2eb823729a8899d5d212186695cea1811324d5d26dd079dc693b90889a', appSecret:'488927e4e34ff34332126d4c9ee6fc8a56c64f3f5f5aca85ceb2e60d693f22c0', callbackUrl:'tigimbal://authcode'});



